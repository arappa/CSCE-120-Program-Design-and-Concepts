#include <iostream>
#include "mystery_formula.h"

using std::cout, std::endl;

int main() {
  bool w;  // TODO: initialize this value
  bool x;  // TODO: initialize this value
  bool y;  // TODO: initialize this value
  bool z;  // TODO: initialize this value
  // if w,x,y,z are set correctly, you will pass the test.
  f(w, x, y, z);
}
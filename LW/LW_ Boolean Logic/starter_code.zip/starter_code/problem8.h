#ifndef PROBLEM_8_H
#define PROBLEM_8_H

// the implementation of this mystery function is provided on the back end
// you do not need to implement it
bool f(bool x, bool y, bool z);

#endif  // PROBLEM_8_H

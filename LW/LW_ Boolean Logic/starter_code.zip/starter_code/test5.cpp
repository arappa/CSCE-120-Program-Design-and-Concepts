#include "boolean_functions.h"

int main() {
    booleanLogic5();

    return 0;
}
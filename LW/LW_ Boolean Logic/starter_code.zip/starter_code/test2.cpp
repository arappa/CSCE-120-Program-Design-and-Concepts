#include "boolean_functions.h"

int main() {
    booleanLogic2();

    return 0;
}
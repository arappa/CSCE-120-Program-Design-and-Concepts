#include "boolean_functions.h"

int main() {
    booleanLogic1();

    return 0;
}
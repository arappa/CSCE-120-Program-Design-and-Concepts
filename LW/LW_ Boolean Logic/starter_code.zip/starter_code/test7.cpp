#include "boolean_functions.h"

int main() {
    booleanLogic7();
    return 0;
}
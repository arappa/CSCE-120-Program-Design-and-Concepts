#include "boolean_functions.h"

int main() {
    booleanLogic6();
    return 0;
}
#include "boolean_functions.h"

int main() {
    booleanLogic3();

    return 0;
}
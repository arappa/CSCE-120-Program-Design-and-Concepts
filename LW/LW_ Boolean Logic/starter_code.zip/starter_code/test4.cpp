#include "boolean_functions.h"

int main() {
    booleanLogic4();

    return 0;
}
#ifndef MYSTERY_FORMULA_H
#define MYSTERY_FORMULA_H

// the implementation of this mystery function is provided on the back end
// you do not need to implement it
void f(bool, bool, bool, bool);

#endif  // MYSTERY_FORMULA_H
